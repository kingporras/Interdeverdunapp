# Inter de Verdun

Sitio oficial del equipo Inter de Verdun.

## Funcionalidades
- Calendario
- Convocatorias
- Formación táctica
- MVP

## Enlaces útiles
- [Liga A](https://apuntamelo.com/grupo/2/504/2/1847/0)
- [Liga B](https://apuntamelo.com/grupo/2/588/2/2434/0)